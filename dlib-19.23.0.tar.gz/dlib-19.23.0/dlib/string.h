// Copyright (C) 2006  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_STRINg_TOP_
#define DLIB_STRINg_TOP_ 

#include "string/string.h"

#endif // DLIB_STRINg_TOP_

